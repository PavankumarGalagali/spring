package com.tyss.custome_exception.customechechkedexception;

public class InsufficientBalanceException  extends Exception{

	
	public InsufficientBalanceException(String msg) {
		super(msg);
	}
	
	@Override
	public String getMessage() {
		
		return super.getMessage();
	}
	
	
	
	
}
