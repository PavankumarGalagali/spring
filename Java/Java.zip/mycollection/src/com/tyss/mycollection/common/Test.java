package com.tyss.mycollection.common;

import com.tyss.mycollection.set.Student;

public class Test {
 public static void main(String[] args) {
	Student student = new Student();
	
	com.tyss.mycollection.arraylist.Student  student2 = new com.tyss.mycollection.arraylist.Student();
}
}
