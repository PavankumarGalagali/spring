package com.tyss.thread.common;

@FunctionalInterface
public interface FunctionalInterfaceTwo {
	public void getData(String n , String m);
}
