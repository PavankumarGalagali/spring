package com.tyss.thread.common;

public enum Movies {
	KGF,Inception
}
