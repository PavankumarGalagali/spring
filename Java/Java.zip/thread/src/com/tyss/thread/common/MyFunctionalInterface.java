package com.tyss.thread.common;


@FunctionalInterface
public interface MyFunctionalInterface {
	public boolean getData(String name);
	
}
