package com.tyss.thread.threadconcepts;

public class Snippet {
	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName());
	}
}

