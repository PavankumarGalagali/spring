package com.tyss.threads.common;

@FunctionalInterface
public interface MyInterface {

	public boolean getData();
}
