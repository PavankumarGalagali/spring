package com.tyss.threads.enumanno;

public enum Movies {
	KGF,NTG,HOLIDAY
}
